//
//  queso.swift
//  PizzaWatch WatchKit Extension
//
//  Created by ALEJANDRO RICO ESPINOSA on 14/05/20.
//  Copyright © 2020 ALEJANDRO RICO ESPINOSA. All rights reserved.
//

import WatchKit

class queso: NSObject {
    
    var tamanio:String=""
    var mas:String=""
    var ques:String=""
    
    init(t:String,m:String,q:String) {
        tamanio=t
        mas=m
        ques=q
    }


}
