//
//  ingre.swift
//  PizzaWatch WatchKit Extension
//
//  Created by ALEJANDRO RICO ESPINOSA on 14/05/20.
//  Copyright © 2020 ALEJANDRO RICO ESPINOSA. All rights reserved.
//

import WatchKit

class ingre: NSObject {
    
    var tamanio:String=""
    var mas:String=""
    var ques:String=""
    var ingred=[String]()
    
    init(t:String,m:String,q:String,i:[String]) {
        tamanio=t
        mas=m
        ques=q
        ingred=i
    }

}
