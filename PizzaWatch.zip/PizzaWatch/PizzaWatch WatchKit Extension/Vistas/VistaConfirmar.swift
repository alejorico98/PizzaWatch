//
//  VistaConfirmar.swift
//  PizzaWatch WatchKit Extension
//
//  Created by ALEJANDRO RICO ESPINOSA on 14/05/20.
//  Copyright © 2020 ALEJANDRO RICO ESPINOSA. All rights reserved.
//

import WatchKit
import Foundation


class VistaConfirmar: WKInterfaceController {

    
    @IBOutlet weak var T: WKInterfaceLabel!
    @IBOutlet weak var M: WKInterfaceLabel!
    @IBOutlet weak var Q: WKInterfaceLabel!
    @IBOutlet weak var I: WKInterfaceLabel!
    

    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        let c = context as! ingre
        
        T.setText(c.tamanio)
        M.setText(c.mas)
        Q.setText(c.ques)
        I.setText("\(c.ingred)")
        
        // Configure interface objects here.
    }

    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

}
