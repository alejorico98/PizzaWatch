//
//  VistaMasa.swift
//  PizzaWatch WatchKit Extension
//
//  Created by ALEJANDRO RICO ESPINOSA on 14/05/20.
//  Copyright © 2020 ALEJANDRO RICO ESPINOSA. All rights reserved.
//

import WatchKit
import Foundation


class VistaMasa: WKInterfaceController {

    //Variables
    var pasTam:String = ""
    
    
    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        let c = context as! tamano
        pasTam = c.tamanio
        // Configure interface objects here.
    }

    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }
    
    @IBAction func delgada() {
        let tam=masa(t: pasTam,m: "Delgada")
        pushController(withName: "VQueso", context: tam)
    }
    @IBAction func crujiente() {
        let tam=masa(t: pasTam,m: "Crujiente")
        pushController(withName: "VQueso", context: tam)
    }
    @IBAction func gruesa() {
        let tam=masa(t: pasTam,m: "Gruesa")
        pushController(withName: "VQueso", context: tam)
    }
    
    

}
