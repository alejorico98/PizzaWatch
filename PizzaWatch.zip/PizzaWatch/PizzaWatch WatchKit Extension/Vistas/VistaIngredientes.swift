//
//  VistaIngredientes.swift
//  PizzaWatch WatchKit Extension
//
//  Created by ALEJANDRO RICO ESPINOSA on 14/05/20.
//  Copyright © 2020 ALEJANDRO RICO ESPINOSA. All rights reserved.
//

import WatchKit
import Foundation


class VistaIngredientes: WKInterfaceController {
    
    //Variables
    var pasTam:String = ""
    var pasMas:String = ""
    var pasQue:String = ""
    var ingredientes=[String]()
    
    var jamo:Bool=false
    var pepp:Bool=false
    var salch:Bool=false
    var pav:Bool=false
    var ace:Bool=false
    var cebo:Bool=false
    var pimi:Bool=false
    var pin:Bool=false
    var anc:Bool=false
    
    @IBOutlet weak var BotJa: WKInterfaceButton!
    @IBOutlet weak var BotPe: WKInterfaceButton!
    @IBOutlet weak var BotSa: WKInterfaceButton!
    @IBOutlet weak var BotPa: WKInterfaceButton!
    @IBOutlet weak var BotAc: WKInterfaceButton!
    @IBOutlet weak var BotCe: WKInterfaceButton!
    @IBOutlet weak var BotPi: WKInterfaceButton!
    

    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        let c = context as! queso
        pasTam = c.tamanio
        pasMas = c.mas
        pasQue = c.ques
        
        // Configure interface objects here.
    }

    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }
    
    @IBAction func Jamon() {
        if jamo==false{
            ingredientes.append("Jamon")
            jamo=true
            BotJa.setBackgroundColor(UIColor.blue)
        }else{
            let indice=ingredientes.firstIndex(of: "Jamon")
                ingredientes.remove(at:(indice!))
            jamo=false
            BotJa.setBackgroundColor(UIColor.white)
        }
    }
    
    @IBAction func Pepperoni() {
        if pepp==false{
            ingredientes.append("Pepperoni")
            pepp=true
            BotPe.setBackgroundColor(UIColor.blue)
            
        }else{
            let indice=ingredientes.firstIndex(of: "Pepperoni")
                ingredientes.remove(at:(indice!))
            pepp=false
            BotPe.setBackgroundColor(UIColor.white)
        }
    }
    
    @IBAction func salchicha() {
        if salch==false{
            ingredientes.append("Salchicha")
            salch=true
            BotSa.setBackgroundColor(UIColor.blue)
            
        }else{
            let indice=ingredientes.firstIndex(of: "Salchicha")
                ingredientes.remove(at:(indice!))
            salch=false
            BotSa.setBackgroundColor(UIColor.white)
        }
    }
    
    @IBAction func pavo() {
        if pav==false{
            ingredientes.append("Pavo")
            pav=true
            BotPa.setBackgroundColor(UIColor.blue)
            
        }else{
            let indice=ingredientes.firstIndex(of: "Pavo")
                ingredientes.remove(at:(indice!))
            pav=false
            BotPa.setBackgroundColor(UIColor.white)
        }
    }
    
    @IBAction func aceituna() {
        if ace==false{
            ingredientes.append("Aceituna")
            ace=true
            BotAc.setBackgroundColor(UIColor.blue)
            
        }else{
            let indice=ingredientes.firstIndex(of: "Aceituna")
                ingredientes.remove(at:(indice!))
            ace=false
            BotAc.setBackgroundColor(UIColor.white)
        }
    }
    
    @IBAction func cebolla() {
        if cebo==false{
            ingredientes.append("Cebolla")
            cebo=true
            BotCe.setBackgroundColor(UIColor.blue)
            
        }else{
            let indice=ingredientes.firstIndex(of: "Cebolla")
                ingredientes.remove(at:(indice!))
            cebo=false
            BotCe.setBackgroundColor(UIColor.white)
        }
    }
    
    @IBAction func piña() {
        if pin==false{
            ingredientes.append("Piña")
            pin=true
            BotPi.setBackgroundColor(UIColor.blue)
            
        }else{
            let indice=ingredientes.firstIndex(of: "Piña")
                ingredientes.remove(at:(indice!))
            pin=false
            BotPi.setBackgroundColor(UIColor.white)
        }
    }
    
    
    @IBAction func Finalizar() {
        let tam=ingre(t: pasTam,m: pasMas,q: pasQue,i: ingredientes)
        pushController(withName: "VConfirmar", context: tam)
    }
    
    

}
