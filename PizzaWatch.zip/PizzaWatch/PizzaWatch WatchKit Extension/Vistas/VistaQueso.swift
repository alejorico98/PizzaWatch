//
//  VistaQueso.swift
//  PizzaWatch WatchKit Extension
//
//  Created by ALEJANDRO RICO ESPINOSA on 14/05/20.
//  Copyright © 2020 ALEJANDRO RICO ESPINOSA. All rights reserved.
//

import WatchKit
import Foundation


class VistaQueso: WKInterfaceController {
    
    //Variables
    var pasTam:String = ""
    var pasMas:String = ""

    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        let c = context as! masa
        pasTam = c.tamanio
        pasMas = c.mas
        // Configure interface objects here.
    }

    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }
    
    @IBAction func mozarela() {
        let tam=queso(t: pasTam,m: pasMas, q: "Mozarela")
        pushController(withName: "VIngredientes", context: tam)
    }
    @IBAction func cheddar() {
        let tam=queso(t: pasTam,m: pasMas, q: "Cheddar")
        pushController(withName: "VIngredientes", context: tam)
    }
    @IBAction func parmesano() {
        let tam=queso(t: pasTam,m: pasMas, q: "Parmesano")
        pushController(withName: "VIngredientes", context: tam)
    }
    @IBAction func sinQueso() {
        let tam=queso(t: pasTam,m: pasMas, q: "Sin Queso")
        pushController(withName: "VIngredientes", context: tam)
    }
    

}
